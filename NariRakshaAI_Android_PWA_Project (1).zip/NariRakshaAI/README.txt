NARIRAKSHA AI — ANDROID INSTALLABLE PWA
=======================================

FILES
- index.html: the app UI and demo functionality
- manifest.json: install metadata and app icon references
- service-worker.js: basic offline caching
- icon-192.png / icon-512.png: app icons

RUN LOCALLY IN VS CODE
1. Extract this ZIP.
2. Open the extracted NariRakshaAI folder in VS Code.
3. Install the "Live Server" extension by Ritwick Dey.
4. Right-click index.html and choose "Open with Live Server".
5. It should open on http://127.0.0.1:5500.

INSTALL ON ANDROID
A PWA must be served from HTTPS (or localhost on the same device) to install reliably.
Easy student option:
1. Upload the extracted folder's files to a static hosting service that provides HTTPS (for example, Netlify Drop or GitHub Pages).
2. Open the HTTPS website URL in Chrome on your Android phone.
3. Open Chrome's menu (three dots) and choose "Install app" or "Add to Home screen".
4. Confirm. NariRaksha will appear on the home screen and open in its own window.

IMPORTANT LIMITATIONS
- This is a student prototype, not a certified emergency service.
- SOS does not automatically alert police or contacts. It opens call/message options, and the user must confirm.
- Location is only requested when the user taps the location button; it does not track in the background.
- The AI assistant is rule-based demo logic, not a live generative AI model.
- Trusted contacts and checklist data are stored in browser localStorage on that device. They are not synced or encrypted by a server.
- Do not rely on this prototype as your only safety measure in a real emergency.
